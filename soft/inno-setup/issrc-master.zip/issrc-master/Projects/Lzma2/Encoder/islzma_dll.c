/*
  islzma_dll.c, by Jordan Russell for Inno Setup
  This file is public domain (like the LZMA SDK)

  $jrsoftware: issrc/Projects/lzma2/Encoder/islzma_dll.c,v 1.2 2010/03/24 19:55:40 jr Exp $
*/

#include <windows.h>

BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	return TRUE;
}
